import os
import cv2
import numpy as np


def imread_chinese(path):
    if not os.path.exists(path):
        raise FileNotFoundError(f"文件不存在: {path}")
    data = np.fromfile(path, dtype=np.uint8)
    img = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError(f"OpenCV 无法解码图片: {path}")
    return img


def keep_largest_component(mask, min_area=100):
    num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
    if num_labels <= 1:
        return np.zeros_like(mask)

    best_label = 0
    best_area = 0
    for i in range(1, num_labels):
        area = stats[i, cv2.CC_STAT_AREA]
        if area >= min_area and area > best_area:
            best_area = area
            best_label = i

    out = np.zeros_like(mask)
    if best_label > 0:
        out[labels == best_label] = 255
    return out


def threshold_red(img):
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    lower_red1 = np.array([0, 80, 80])
    upper_red1 = np.array([10, 255, 255])
    lower_red2 = np.array([170, 80, 80])
    upper_red2 = np.array([180, 255, 255])

    mask1 = cv2.inRange(hsv, lower_red1, upper_red1)
    mask2 = cv2.inRange(hsv, lower_red2, upper_red2)
    return cv2.bitwise_or(mask1, mask2)


def threshold_black(img):
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    lower_black = np.array([0, 0, 0])
    upper_black = np.array([180, 120, 90])
    return cv2.inRange(hsv, lower_black, upper_black)


def fill_region_from_open_contour(mask, close_kernel=9, dilate_iter=2, min_area=100):
    kernel = np.ones((close_kernel, close_kernel), np.uint8)

    # 先保留主轮廓，减少噪声
    main = keep_largest_component(mask, min_area=min_area)

    # 补齐断裂处并适当加粗轮廓
    closed = cv2.morphologyEx(main, cv2.MORPH_CLOSE, kernel, iterations=1)
    thick = cv2.dilate(closed, np.ones((3, 3), np.uint8), iterations=dilate_iter)

    # 用 flood fill 填充闭合轮廓内部
    flood = thick.copy()
    h, w = flood.shape
    flood_mask = np.zeros((h + 2, w + 2), np.uint8)
    cv2.floodFill(flood, flood_mask, (0, 0), 255)

    holes = cv2.bitwise_not(flood)
    region = cv2.bitwise_or(holes, thick)

    # 再保留最大填充区域
    contours, _ = cv2.findContours(region, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    filled = np.zeros_like(region)
    if contours:
        largest = max(contours, key=cv2.contourArea)
        cv2.drawContours(filled, [largest], -1, 255, thickness=cv2.FILLED)

    return main, closed, thick, filled


def extract_region(image_path, color):
    img = imread_chinese(image_path)

    if color == "red":
        raw_mask = threshold_red(img)
        main, closed, thick, region = fill_region_from_open_contour(
            raw_mask, close_kernel=9, dilate_iter=2, min_area=80
        )
    elif color == "black":
        raw_mask = threshold_black(img)
        main, closed, thick, region = fill_region_from_open_contour(
            raw_mask, close_kernel=11, dilate_iter=2, min_area=80
        )
    else:
        raise ValueError("color 只能是 'red' 或 'black'")

    return img, raw_mask, main, closed, thick, region


def compute_overlap_from_two_images(red_image_path, black_image_path, show=True):
    red_img, red_raw, red_main, red_closed, red_thick, red_region = extract_region(red_image_path, "red")
    black_img, black_raw, black_main, black_closed, black_thick, black_region = extract_region(black_image_path, "black")

    red_bool = red_region > 0
    black_bool = black_region > 0

    intersection = np.logical_and(red_bool, black_bool).sum()
    red_area = red_bool.sum()
    overlap_ratio = intersection / red_area if red_area > 0 else 0.0

    print("红色图片:", red_image_path)
    print("黑色图片:", black_image_path)
    print(f"红色区域面积: {red_area}")
    print(f"黑红重叠面积: {intersection}")
    print(f"堆积区域重叠率: {overlap_ratio:.4f}")
    print(f"堆积区域重叠率: {overlap_ratio * 100:.2f}%")

    if show:
        h = min(red_region.shape[0], black_region.shape[0])
        w = min(red_region.shape[1], black_region.shape[1])

        red_bool = red_bool[:h, :w]
        black_bool = black_bool[:h, :w]
        base = red_img[:h, :w].copy()

        overlay = base.copy()
        overlay[red_bool] = [0, 0, 255]
        overlay[black_bool] = [0, 255, 0]
        overlay[np.logical_and(red_bool, black_bool)] = [0, 255, 255]

        cv2.imshow("Red Raw Mask", red_raw)
        cv2.imshow("Red Main", red_main)
        cv2.imshow("Red Closed", red_closed)
        cv2.imshow("Red Region", red_region)

        cv2.imshow("Black Raw Mask", black_raw)
        cv2.imshow("Black Main", black_main)
        cv2.imshow("Black Closed", black_closed)
        cv2.imshow("Black Region", black_region)

        cv2.imshow("Overlay", overlay)
        cv2.waitKey(0)
        cv2.destroyAllWindows()

    return overlap_ratio


if __name__ == "__main__":
    red_image_path = r"C:\Users\admin\Desktop\小论文\三维地震滑坡\FEM-SPH地震响应验证\red.png"
    black_image_path = r"C:\Users\admin\Desktop\小论文\三维地震滑坡\FEM-SPH地震响应验证\black.png"
    compute_overlap_from_two_images(red_image_path, black_image_path, show=True)